﻿import { NavContextMenuPatchCallback } from "@api/ContextMenu";
import { definePluginSettings } from "@api/Settings";
import definePlugin, { OptionType } from "@utils/types";
import { Menu } from "@webpack/common";

const settings = definePluginSettings({
    uiDialect: {
        type: OptionType.SELECT,
        description: "Язык интерфейса Discord и входящих сообщений",
        options: [
            { label: "Муринский (я-ч, друг-друн, +ость)", value: "murino", default: true },
            { label: "Село Молочное (павук, трамвай, +очность)", value: "molch" },
            { label: "Мытищинский (Перловка, Яуза, +ищи)", value: "mitish" },
            { label: "Меллстройский (всеобщий стримерский)", value: "mell" },
            { label: "Выключить перевод интерфейса", value: "none" }
        ],
        onChange: () => {
            walkAndTranslate(document.body, true);
            if (settings.store.uiDialect !== "none") {
                walkAndTranslate(document.body, false);
            }
        }
    },
    sendMode: {
        type: OptionType.SELECT,
        description: "Режим перевода моих отправляемых сообщений",
        options: [
            { label: "Спрашивать при отправке (окно выбора 1-4)", value: "ask", default: true },
            { label: "Всегда Муринский", value: "murino" },
            { label: "Всегда Село Молочное", value: "molch" },
            { label: "Всегда Мытищинский", value: "mitish" },
            { label: "Всегда Меллстройский (Всеобщий)", value: "mell" },
            { label: "Не переводить мои сообщения", value: "none" }
        ]
    }
});

const STOP_WORDS = new Set([
    "ты", "он", "она", "оно", "мы", "вы", "они", "меня", "тебя", "его", "ее", "её", "нас", "вас", "их",
    "мне", "тебе", "ему", "ей", "нам", "вам", "им", "мной", "тобой", "нами", "вами", "ими",
    "мой", "моя", "моё", "мои", "твой", "твоя", "твоё", "твои", "наш", "наша", "наше", "наши", "ваш", "ваша",
    "что", "как", "где", "когда", "куда", "откуда", "почему", "зачем", "кто", "кого", "кому", "кем",
    "это", "эта", "этот", "эти", "того", "тому", "тем", "том", "весь", "вся", "всё", "все", "всех", "всем",
    "или", "либо", "если", "чтобы", "хотя", "пока", "даже", "уже", "еще", "ещё", "тоже", "также", "просто",
    "очень", "почти", "вдруг", "здесь", "тут", "там", "сюда", "туда", "сейчас", "потом", "теперь", "всегда",
    "никогда", "иногда", "нет", "да", "не", "ни", "но", "а", "и", "в", "на", "с", "со", "к", "ко", "о", "об",
    "у", "за", "из", "от", "до", "по", "под", "над", "при", "про", "без", "для", "через", "между", "перед"
]);

const VERB_ENDINGS = [
    "ться", "тся", "тись", "чься",
    "ать", "ять", "еть", "ить", "оть", "уть", "ыть", "ти", "чь",
    "ала", "ало", "али", "ял", "яла", "яло", "яли",
    "ела", "ело", "ели", "ила", "ило", "или",
    "ула", "уло", "ули", "ыла", "ыло", "ыли",
    "ает", "яет", "еет", "ит", "ут", "ют", "ат", "ят",
    "аем", "яем", "еем", "им", "ем", "ём",
    "аешь", "яешь", "еешь", "ишь", "ешь", "ёшь",
    "аете", "яете", "еете", "ите", "ете", "ёте",
    "ают", "яют", "еют",
    "ал", "ел", "ил", "ул", "ыл", "ол",
    "ай", "ей", "ий", "уй", "ьте", "ите",
    "ая", "яя", "в", "вши", "вшись"
];

const VERB_EXCEPTIONS = new Set([
    "есть", "быть", "был", "была", "было", "были", "будет", "будут", "буду", "будем", "будешь", "будете",
    "иду", "идет", "идёт", "идут", "шел", "шёл", "шла", "шло", "шли", "пойти", "пошел", "пошёл",
    "могу", "может", "могут", "мог", "могла", "могли", "хочу", "хочет", "хотят", "хотел", "хотела",
    "знаю", "знает", "знают", "делаю", "делает", "делают", "сделал", "сделала", "сделали", "сделать",
    "вижу", "видит", "видят", "видел", "скажу", "скажет", "сказал", "сказала", "говорит", "говорят",
    "пишу", "пишет", "пишут", "написал", "написала", "написать", "читаю", "читает", "читают", "еду", "едет", "едут",
    "люблю", "любит", "любят", "любишь", "любим", "любите", "любил", "любила"
]);

const MURINO_DICT: Record<string, string> = {
    "я": "ч",
    "друг": "друн", "друга": "друна", "другу": "друну", "другом": "друном", "друге": "друне",
    "друзья": "друны", "друзей": "друнов", "друзьям": "друнам", "друзьями": "друнами", "друзьях": "друнах",
    "сын": "сыр", "сына": "сыра", "сыну": "сыру", "сыном": "сыром", "сыне": "сыре",
    "сыновья": "сыры", "сыновей": "сыров", "сыновьям": "сырам", "сыновьями": "сырами"
};

const MOLCH_DICT: Record<string, string> = {
    "я": "ч",
    "друг": "павук", "друга": "павука", "другу": "павуку", "другом": "павуком",
    "друзья": "павуки", "друзей": "павуков", "друзьям": "павукам",
    "поезд": "трамвай", "поезда": "трамвая", "автобус": "трамвай", "машина": "трамвай", "метро": "трамвай",
    "город": "Село Молочное", "города": "Села Молочного", "село": "Село Молочное", "деревня": "Село Молочное",
    "сервер": "пансионат Береговой", "сервера": "пансионата Береговой",
    "канал": "Паучья яма", "канала": "Паучьей ямы",
    "кот": "тарантул", "кота": "тарантула", "собака": "паучара", "собаки": "паучары",
    "вода": "молочко", "воды": "молочка", "чай": "кефирность", "кофе": "сметанность",
    "музыка": "Crna dvojka", "песня": "Vozi lola Audia", "трек": "Crna dvojka",
    "привет": "кулити в Молочном", "пока": "уехал на трамвае",
    "хорошо": "молочно", "круто": "трамвайно", "плохо": "паучно"
};

const MITISH_DICT: Record<string, string> = {
    "я": "мытищинец",
    "друг": "земляк с Перловки", "друга": "земляка с Перловки", "другу": "земляку с Перловки", "другом": "земляком с Перловки",
    "друзья": "мытищинцы", "друзей": "мытищинцев", "друзьям": "мытищинцам",
    "поезд": "электричка Спутник", "поезда": "электрички Спутник",
    "метро": "Ярославское направление", "вокзал": "станция Мытищи",
    "станция": "Перловская", "остановка": "Тайнинская",
    "город": "Мытищи", "города": "Мытищ", "городу": "Мытищам", "городом": "Мытищами",
    "район": "Перловка", "района": "Перловки",
    "дом": "панелька в Леонидовке", "дома": "панельки в Леонидовке", "квартира": "однушка у Яузы",
    "сервер": "Красный Кит", "сервера": "Красного Кита",
    "магазин": "Мытищинская ярмарка", "рынок": "Мытищинская ярмарка",
    "река": "Яуза", "вода": "вода из Яузы", "воды": "воды из Яузы",
    "чай": "мытищинское чаепитие", "кофе": "чаепитие у Перова",
    "дорога": "Ярославка", "пробка": "Ярославка стоит", "пробки": "стояк на Ярославке", "машина": "ласточка на Ярославке",
    "привет": "салют с Перловки", "пока": "уехал на Спутнике",
    "хорошо": "по-мытищински чётко", "круто": "мощно как Спутник", "плохо": "как в час пик на Ярославке"
};

const MELL_DICT: Record<string, string> = {
    "я": "я",
    "друг": "братик", "друга": "братика", "другу": "братику", "другом": "братиком",
    "друзья": "братва", "друзей": "братвы", "друзьям": "братве",
    "человек": "типок", "люди": "чатик", "людей": "чатика",
    "деньги": "бабки", "денег": "бабок", "деньгами": "бабками",
    "миллион": "лям", "миллионов": "лямов", "тысяча": "косарь", "тысяч": "косарей",
    "выигрыш": "занос", "победа": "лютый занос", "поражение": "тильт", "проигрыш": "слив",
    "казино": "казик", "игра": "катка", "игры": "катки",
    "стрим": "подрубка", "стрима": "подрубки", "видео": "нарезка",
    "машина": "бэха", "машины": "бэхи", "дом": "пентхаус", "квартира": "хата в Сити",
    "девушка": "моделька", "девушки": "модельки",
    "привет": "салам братва", "пока": "давай на связи братик",
    "да": "база", "нет": "мимо кассы",
    "хорошо": "кайфово", "отлично": "жирно", "круто": "люто", "плохо": "тильтово",
    "много": "до талого", "быстро": "на суете", "правда": "факты"
};

const CYRILLIC_CHECK = new RegExp("[\\u0410-\\u044F\\u0401\\u0451]");
const CYRILLIC_WORDS = new RegExp("[\\u0410-\\u044F\\u0401\\u0451]+", "g");
const TRAILING_VOWEL = new RegExp("[\\u0430\\u044F\\u043E\\u0435\\u0443\\u044B\\u0438\\u044E\\u044D\\u044C\\u0439]$");
const HUSHING_END = new RegExp("[\\u0447\\u0448\\u0449\\u0436]$");
const VELAR_END = new RegExp("[\\u0433\\u043A\\u0445\\u0436\\u0447\\u0448\\u0449]$");

function preserveCase(original: string, translated: string): string {
    if (!original || !translated) return translated;
    if (original === original.toUpperCase() && original.length > 1) return translated.toUpperCase();
    if (original === original.toUpperCase()) return translated.toUpperCase() + translated.slice(1);
    return translated;
}

function isVerb(lower: string): boolean {
    if (VERB_EXCEPTIONS.has(lower)) return true;
    if (lower.length < 4) return false;
    return VERB_ENDINGS.some(end => lower.endsWith(end));
}

function translateMurino(text: string): string {
    if (!text || !CYRILLIC_CHECK.test(text)) return text;
    return text.replace(CYRILLIC_WORDS, word => {
        const lower = word.toLowerCase();
        if (MURINO_DICT[lower]) return preserveCase(word, MURINO_DICT[lower]);
        if (lower.length <= 2 || STOP_WORDS.has(lower) || isVerb(lower) || lower.endsWith("ость") || lower.endsWith("ось")) return word;
        const stem = lower.replace(TRAILING_VOWEL, "");
        return stem.length < 2 ? word : preserveCase(word, stem + "ость");
    });
}

function translateMolch(text: string): string {
    if (!text || !CYRILLIC_CHECK.test(text)) return text;
    return text.replace(CYRILLIC_WORDS, word => {
        const lower = word.toLowerCase();
        if (MOLCH_DICT[lower]) return preserveCase(word, MOLCH_DICT[lower]);
        if (lower.length <= 3 || STOP_WORDS.has(lower) || isVerb(lower) || lower.endsWith("очность") || lower.endsWith("ость")) return word;
        const stem = lower.replace(TRAILING_VOWEL, "");
        if (stem.length < 2) return word;
        return preserveCase(word, stem + (HUSHING_END.test(stem) ? "ность" : "очность"));
    });
}

function translateMitish(text: string): string {
    if (!text || !CYRILLIC_CHECK.test(text)) return text;
    return text.replace(CYRILLIC_WORDS, word => {
        const lower = word.toLowerCase();
        if (MITISH_DICT[lower]) return preserveCase(word, MITISH_DICT[lower]);
        if (lower.length <= 3 || STOP_WORDS.has(lower) || isVerb(lower) || lower.endsWith("ищи") || lower.endsWith("инск")) return word;
        const stem = lower.replace(TRAILING_VOWEL, "");
        if (stem.length < 2) return word;
        return preserveCase(word, stem + (VELAR_END.test(stem) ? "инск" : "ищи"));
    });
}
function translateMell(text: string): string {
    if (!text || !CYRILLIC_CHECK.test(text)) return text;
    return text.replace(CYRILLIC_WORDS, word => {
        const lower = word.toLowerCase();
        if (MELL_DICT[lower]) return preserveCase(word, MELL_DICT[lower]);
        if (lower.length <= 3 || STOP_WORDS.has(lower) || isVerb(lower) || lower.endsWith("ость")) return word;
        const stem = lower.replace(TRAILING_VOWEL, "");
        if (stem.length < 3) return word;
        return preserveCase(word, stem + "ость");
    });
}
function translateByDialect(text: string, dialect: string): string {
    if (dialect === "murino") return translateMurino(text);
    if (dialect === "molch") return translateMolch(text);
    if (dialect === "mitish") return translateMitish(text);
    if (dialect === "mell") return translateMell(text);
    return text;
}
const originalTexts = new WeakMap<Text, string>();
const translatedTexts = new WeakMap<Text, string>();
const bypassedMessages = new WeakSet();
const sentRawMessages = new Set();
let observer: MutationObserver | null = null;
function isInsideBypassedMessage(el: Element | null): boolean {
    if (!el) return false;
    const msgEl = el.closest('[id^="chat-messages-"], [class*="message-"]');
    return msgEl ? bypassedMessages.has(msgEl) : false;
}
function processTextNode(node: Text) {
    const dialect = settings.store.uiDialect;
    if (!dialect || dialect === "none") return;
    const parent = node.parentElement;
    if (!parent) return;
    if (
        parent.isContentEditable ||
        ["INPUT", "TEXTAREA", "CODE", "PRE", "SCRIPT", "STYLE"].includes(parent.tagName) ||
        parent.closest('[role="textbox"]')
    ) {
        return;
    }
    if (isInsideBypassedMessage(parent)) return;
    const currentVal = node.nodeValue;
    if (!currentVal) return;
    if (sentRawMessages.has(currentVal.trim())) return;
    if (translatedTexts.get(node) === currentVal) return;
    if (!originalTexts.has(node)) {
        originalTexts.set(node, currentVal);
    }
    const baseText = originalTexts.get(node)!;
    const translated = translateByDialect(baseText, dialect);
    if (translated !== currentVal) {
        translatedTexts.set(node, translated);
        node.nodeValue = translated;
    }
}
function walkAndTranslate(root: Node, restoreOriginal = false) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node: Node | null;
    while ((node = walker.nextNode())) {
        const textNode = node as Text;
        if (restoreOriginal) {
            const orig = originalTexts.get(textNode);
            if (orig !== undefined && textNode.nodeValue !== orig) {
                textNode.nodeValue = orig;
            }
        } else {
            processTextNode(textNode);
        }
    }
}
function findMessageElement(messageId: string): Element | null {
    return (
        document.querySelector('[id$="-' + messageId + '"]') ||
        document.querySelector('[data-list-item-id*="' + messageId + '"]')
    );
}
const MessageContextPatch: NavContextMenuPatchCallback = (children, { message }) => {
    if (!message?.id) return;
    const msgEl = findMessageElement(message.id);
    if (!msgEl) return;
    const isBypassed = bypassedMessages.has(msgEl);
    children.push(
        <Menu.MenuItem
            id="mellstroy-toggle-translation"
            label={isBypassed ? "Перевести на выбранный диалект" : "Убрать мемный перевод"}
            action={() => {
                if (bypassedMessages.has(msgEl)) {
                    bypassedMessages.delete(msgEl);
                    walkAndTranslate(msgEl, false);
                } else {
                    bypassedMessages.add(msgEl);
                    walkAndTranslate(msgEl, true);
                }
            }}
        />
    );
};
function askDialectChoice(originalContent: string): Promise<string | null> {
    return new Promise(resolve => {
        let settled = false;
        const choices = [
            { key: "1", label: "1. Муринский (я-ч, друг-друн, +ость)", accent: "#5865F2", text: translateMurino(originalContent) },
            { key: "2", label: "2. Село Молочное (павук, трамвай, +очность)", accent: "#248046", text: translateMolch(originalContent) },
            { key: "3", label: "3. Мытищинский (Перловка, Яуза, +ищи)", accent: "#d97706", text: translateMitish(originalContent) },
            { key: "4", label: "4. Меллстройский (всеобщий стримерский)", accent: "#db2777", text: translateMell(originalContent) }
        ];
        const overlay = document.createElement("div");
        overlay.style.cssText = "position: fixed; inset: 0; z-index: 99999; background: rgba(0, 0, 0, 0.72); display: flex; align-items: center; justify-content: center; font-family: sans-serif;";
        const box = document.createElement("div");
        box.style.cssText = "width: 450px; max-width: 92vw; background: #313338; color: #f2f3f5; border-radius: 12px; padding: 20px; box-shadow: 0 8px 32px rgba(0,0,0,0.6); display: flex; flex-direction: column; gap: 10px;";
        const cleanup = (result: string | null) => {
            if (settled) return;
            settled = true;
            window.removeEventListener("keydown", onKey);
            overlay.remove();
            resolve(result);
        };
        const onKey = (e: KeyboardEvent) => {
            if (e.key === "Escape") {
                e.preventDefault();
                cleanup(null);
            } else if (e.key === "1") {
                e.preventDefault();
                cleanup(choices.at(0)!.text);
            } else if (e.key === "2") {
                e.preventDefault();
                cleanup(choices.at(1)!.text);
            } else if (e.key === "3") {
                e.preventDefault();
                cleanup(choices.at(2)!.text);
            } else if (e.key === "4") {
                e.preventDefault();
                cleanup(choices.at(3)!.text);
            } else if (e.key === "0") {
                e.preventDefault();
                cleanup(originalContent);
            }
        };
        const header = document.createElement("div");
        header.style.cssText = "display: flex; justify-content: space-between; align-items: center;";
        const title = document.createElement("div");
        title.textContent = "Выбери язык отправки (клавиши 1-4)";
        title.style.cssText = "font-size: 16px; font-weight: 700;";
        const closeBtn = document.createElement("button");
        closeBtn.textContent = "✕";
        closeBtn.style.cssText = "background: transparent; border: none; color: #949ba4; font-size: 18px; cursor: pointer; padding: 2px 6px;";
        closeBtn.onclick = () => cleanup(null);
        header.append(title, closeBtn);
        box.appendChild(header);
        choices.forEach(item => {
            const card = document.createElement("div");
            card.style.cssText = "background: #2b2d31; border-radius: 8px; padding: 10px; display: flex; flex-direction: column; gap: 6px;";
            const btn = document.createElement("button");
            btn.textContent = item.label;
            btn.style.cssText = "background: " + item.accent + "; color: #fff; border: none; border-radius: 6px; padding: 8px 12px; font-weight: 600; font-size: 13px; cursor: pointer; text-align: left;";
            btn.onclick = () => cleanup(item.text);
            const textEl = document.createElement("div");
            textEl.textContent = item.text;
            textEl.style.cssText = "font-size: 13px; opacity: 0.9; word-break: break-word;";
            card.append(btn, textEl);
            box.appendChild(card);
        });
        const origBtn = document.createElement("button");
        origBtn.textContent = "0. Отправить оригинал без перевода";
        origBtn.style.cssText = "margin-top: 4px; background: transparent; border: 1px solid #4e5058; color: #f2f3f5; border-radius: 6px; padding: 8px; font-size: 13px; cursor: pointer;";
        origBtn.onclick = () => cleanup(originalContent);
        box.appendChild(origBtn);
        overlay.appendChild(box);
        overlay.onclick = e => {
            if (e.target === overlay) cleanup(null);
        };
        window.addEventListener("keydown", onKey);
        document.body.appendChild(overlay);
    });
}
export default definePlugin({
    name: "MellstroyMemesTranslate",
    description: "Единый переводчик: Муринский, Село Молочное, Мытищинский и Меллстройский + окно выбора (1-4) и откат по ПКМ",
    authors: [{ name: "𝓈𝓌ℯℯ𝓉𝓎 𝓁𝒾𝓉𝓉𝓁ℯ 𝒷𝒶𝒷𝓎 (@myloveitskirill)", id: 1399448306194714786n }],
    settings,
    contextMenus: {
        "message": MessageContextPatch
    },
    start() {
        if (settings.store.uiDialect !== "none") {
            walkAndTranslate(document.body);
        }
        const obs = new MutationObserver(mutations => {
            if (settings.store.uiDialect === "none") return;
            for (const mutation of mutations) {
                if (mutation.type === "characterData" && mutation.target.nodeType === Node.TEXT_NODE) {
                    processTextNode(mutation.target as Text);
                } else if (mutation.type === "childList") {
                    mutation.addedNodes.forEach(added => {
                        if (added.nodeType === Node.TEXT_NODE) {
                            processTextNode(added as Text);
                        } else if (added.nodeType === Node.ELEMENT_NODE) {
                            walkAndTranslate(added);
                        }
                    });
                }
            }
        });
        obs.observe(document.body, {
            childList: true,
            subtree: true,
            characterData: true
        });
        observer = obs;
    },
    stop() {
        walkAndTranslate(document.body, true);
        observer?.disconnect();
        observer = null;
    },
    async onBeforeMessageSend(_, msg) {
        if (!msg.content || !CYRILLIC_CHECK.test(msg.content)) return;
        const mode = settings.store.sendMode;
        if (!mode || mode === "none") return;
        if (mode === "ask") {
            const chosenText = await askDialectChoice(msg.content);
            if (chosenText === null) {
                return { cancel: true };
            }
            msg.content = chosenText;
        } else {
            msg.content = translateByDialect(msg.content, mode);
        }
        sentRawMessages.add(msg.content.trim());
    }
});